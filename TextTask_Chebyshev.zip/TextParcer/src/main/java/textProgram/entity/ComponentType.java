package textProgram.entity;

public enum ComponentType {
    TEXT,
    PARAGRAPH,
    SENTENCE,
    LEXEME,
    SYMBOL,
    LETTER,
    PUNCTUATION
}
